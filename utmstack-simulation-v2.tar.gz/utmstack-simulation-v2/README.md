# 🚀 Environnement de Simulation UTMStack v11 - Version 2.0

Environnement Docker professionnel adapté pour **UTMStack v11** avec les **ports officiels** :
- **Port 7014** : Syslog (Cisco, Windows, AD, VPN, DNS, Proxy)
- **Port 7005** : FortiGate
- **Agent UTMStack** : Nginx, Apache (via Filebeat)

## 📋 Différences avec la v1

| Aspect | Version 1 | Version 2 (Actuelle) |
|--------|-----------|----------------------|
| Port Syslog | 514 ❌ | 7014 ✅ |
| Port FortiGate | 514 ❌ | 7005 ✅ |
| Logs Web | Syslog ❌ | Agent + Filebeat ✅ |
| Compatible UTMStack | Non | Oui ✅ |

## 🎯 Architecture

```
┌─────────────────────────────────────────┐
│         UTMStack v11 Server             │
│  ┌─────────────────────────────────┐   │
│  │  Port 7014/UDP ← Syslog         │   │
│  │  Port 7005/UDP ← FortiGate      │   │
│  │  Agent UTMStack ← Nginx/Apache  │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
           ▲        ▲        ▲
           │        │        │
    ┌──────┴──┐ ┌──┴───┐ ┌─┴────┐
    │ Cisco   │ │ FW   │ │ Web  │
    │ Switch  │ │ FGT  │ │ Srv  │
    └─────────┘ └──────┘ └──────┘
```

## ⚡ Installation rapide

```bash
# 1. Télécharger l'archive
cd /opt
tar -xzf utmstack-simulation-v2.tar.gz
cd utmstack-simulation

# 2. Installer
chmod +x install.sh
./install.sh

# 3. Démarrer
docker-compose up -d

# 4. Vérifier
docker-compose ps
tail -f /var/log/utmstack-simulation/syslog.log
```

## 📊 Simulateurs inclus

### 1. Cisco Switch (Port 7014)
- Logs : Port up/down, BPDU, security violations
- Format : Cisco IOS syslog

### 2. Cisco Router (Port 7014)
- Logs : BGP, OSPF, ACL denies, login
- Format : Cisco IOS syslog

### 3. FortiGate Firewall (Port 7005)
- Logs : Traffic, UTM, IPS, antivirus, web filter
- Format : FortiOS CEF

### 4. Windows Server (Port 7014)
- Logs : Security events, Sysmon
- Event IDs : 4624, 4625, 4720, 4728, 4740

### 5. Active Directory (Port 7014)
- Logs : Authentication, Kerberos, object changes

### 6. VPN Gateway (Port 7014)
- Logs : Connexions, déconnexions, auth failures

### 7. DNS Server (Port 7014)
- Logs : Queries, malicious domain blocks

### 8. Proxy Squid (Port 7014)
- Logs : Web traffic, access logs

### 9. Nginx Web Server (Agent)
- Logs via Filebeat module Apache
- Fichiers : /var/log/utmstack-simulation/nginx/

### 10. Apache Web Server (Agent)
- Logs via Filebeat module Nginx
- Fichiers : /var/log/utmstack-simulation/apache/

## 🔧 Configuration UTMStack

### Étape 1 : Activer l'intégration Syslog

1. Aller dans **Integrations** > **Syslog**
2. Cliquer sur **Enable**
3. Sélectionner :
   - **Platform** : Linux
   - **Protocol** : UDP
   - **Action** : Listen

### Étape 2 : Activer l'intégration FortiGate

1. Aller dans **Integrations** > **FortiGate**
2. Cliquer sur **Enable**
3. Sélectionner :
   - **Platform** : Linux
   - **Protocol** : UDP
   - **Action** : Listen

### Étape 3 : Vérifier l'Agent UTMStack

1. Aller dans **Data Sources** > **Agents**
2. Vérifier que l'agent du serveur apparaît
3. Modules Filebeat actifs : Apache, Nginx

## 🧪 Tests

### Test FortiGate (Port 7005)

```bash
echo "<134>$(date '+%b %d %H:%M:%S') FGT-TEST type=traffic action=accept" | nc -u 10.10.1.230 7005
```

### Test Syslog (Port 7014)

```bash
echo "<134>$(date '+%b %d %H:%M:%S') CORE-SW-01 %LINK-3-UPDOWN: Interface Gi0/1, changed state to up" | nc -u 10.10.1.230 7014
```

### Vérifier les logs

```bash
# FortiGate
tail -f /var/log/utmstack-simulation/fortigate.log

# Syslog général
tail -f /var/log/utmstack-simulation/syslog.log

# Nginx
tail -f /var/log/utmstack-simulation/nginx/access.log

# Apache
tail -f /var/log/utmstack-simulation/apache/access_log
```

## 📈 Vérification dans UTMStack

1. **Log Explorer** : Chercher `FGT-PERIMETER-01` ou `CORE-SW-01`
2. **Dashboards** : Vérifier les graphiques de trafic
3. **Alerts** : Vérifier les règles de corrélation

## 🎓 Volume de logs estimé

- **Par minute** : ~50-60 événements
- **Par heure** : ~3,000 événements
- **Par jour** : ~72,000 événements

## 📂 Structure des fichiers

```
/opt/utmstack-simulation/
├── docker-compose.yml
├── install.sh
├── README.md
├── scripts/
│   ├── fortigate_sim.py
│   ├── cisco_switch_sim.py
│   ├── cisco_router_sim.py
│   ├── windows_events_sim.py
│   ├── ad_events_sim.py
│   ├── vpn_sim.py
│   ├── dns_sim.py
│   ├── proxy_sim.py
│   └── monitoring_dashboard.py
└── config/
    └── (configurations)
```

## 🔥 Commandes utiles

```bash
# Démarrer
docker-compose up -d

# Arrêter
docker-compose down

# Voir les logs
docker-compose logs -f | grep SENT

# Redémarrer un simulateur
docker-compose restart fortigate_simulator

# Voir l'état
docker-compose ps
```

## 🆘 Dépannage

### Les logs n'arrivent pas dans UTMStack

1. Vérifier que les ports sont ouverts :
   ```bash
   netstat -uln | grep -E "7014|7005"
   ```

2. Vérifier que les intégrations sont activées dans UTMStack

3. Vérifier les logs locaux :
   ```bash
   tail -f /var/log/utmstack-simulation/*.log
   ```

### Un simulateur ne démarre pas

```bash
docker-compose logs NOM_SIMULATEUR
docker-compose restart NOM_SIMULATEUR
```

## 📚 Documentation

- **UTMStack Docs** : https://documentation.utmstack.com
- **Intégrations** : https://documentation.utmstack.com/integrations

## ✅ Checklist d'installation

- [ ] Ports 7014 et 7005 ouverts (ufw)
- [ ] rsyslog configuré et redémarré
- [ ] Agent UTMStack installé
- [ ] Modules Filebeat configurés
- [ ] Docker Compose démarré
- [ ] Intégrations activées dans UTMStack
- [ ] Logs visibles dans Log Explorer

---

**Version** : 2.0  
**Compatible avec** : UTMStack v11.x  
**Date** : Février 2026
