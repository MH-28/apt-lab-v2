#!/bin/bash
# Installation de l'environnement de simulation UTMStack v11
# Adapté aux ports officiels UTMStack

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}"
cat << "EOF"
╦ ╦╔╦╗╔╦╗╔═╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╦╔╦╗╦ ╦╦  ╔═╗╔╦╗╦╔═╗╔╗╔
║ ║ ║ ║║║╚═╗ ║ ╠═╣║  ╠╩╗  ╚═╗║║║║║ ║║  ╠═╣ ║ ║║ ║║║║
╚═╝ ╩ ╩ ╩╚═╝ ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╩╩ ╩╚═╝╩═╝╩ ╩ ╩ ╩╚═╝╝╚╝
         Version 2.0 - Adaptée pour UTMStack v11
EOF
echo -e "${NC}"

INSTALL_DIR="/opt/utmstack-simulation"

echo -e "${GREEN}📋 Étape 1 : Configuration des ports UTMStack${NC}"

# Configurer rsyslog pour écouter sur les ports UTMStack
cat > /etc/rsyslog.d/99-utmstack-ports.conf <<'EOF'
# Port 7014 - Syslog général (Cisco, Windows, AD, etc.)
module(load="imudp")
input(type="imudp" port="7014" address="10.10.1.230")

# Port 7005 - FortiGate
input(type="imudp" port="7005" address="10.10.1.230")

# Écrire tous les logs dans des fichiers séparés
if $inputname == "imudp" and $fromhost-ip == "172.30.2.10" then {
    /var/log/utmstack-simulation/fortigate.log
    stop
}

if $inputname == "imudp" then {
    /var/log/utmstack-simulation/syslog.log
}
EOF

echo -e "${GREEN}📋 Étape 2 : Ouverture des ports firewall${NC}"

# Ouvrir les ports nécessaires
ufw allow 7014/udp comment "UTMStack Syslog"
ufw allow 7005/udp comment "UTMStack FortiGate"
ufw allow 5000/tcp comment "Dashboard Simulation"

# Redémarrer rsyslog
systemctl restart rsyslog

echo -e "${GREEN}📋 Étape 3 : Vérification des ports${NC}"

sleep 2
netstat -uln | grep -E "7014|7005"

echo ""
echo -e "${GREEN}📋 Étape 4 : Création des dossiers${NC}"

mkdir -p "$INSTALL_DIR"
mkdir -p /var/log/utmstack-simulation/{nginx,apache}
chmod -R 777 /var/log/utmstack-simulation

echo -e "${GREEN}📋 Étape 5 : Installation de l'Agent UTMStack${NC}"

# Installer l'agent UTMStack sur le serveur
if ! systemctl status utmstack-agent &>/dev/null; then
    echo "Installation de l'agent UTMStack..."
    sudo bash -c "apt update -y && apt install wget -y && \
        mkdir -p /opt/utmstack-linux-agent && \
        wget --no-check-certificate -P /opt/utmstack-linux-agent \
        https://localhost:9001/private/dependencies/agent/utmstack_agent_service && \
        chmod -R 755 /opt/utmstack-linux-agent/utmstack_agent_service && \
        /opt/utmstack-linux-agent/utmstack_agent_service install localhost c3J2LWFwdGl0dWRlLTF8MVhYNXlveFNUZHBwM0ZiQ1duZXI5WXVzbndHWXY3Vlk1SXBUcm5ab0JOOD0= yes"
    
    sleep 5
    systemctl status utmstack-agent
else
    echo -e "${YELLOW}Agent UTMStack déjà installé${NC}"
fi

echo -e "${GREEN}📋 Étape 6 : Configuration de l'agent pour les logs web${NC}"

# Configurer Filebeat pour Apache et Nginx
mkdir -p /etc/utmstack-agent/beats/filebeat/modules.d

# Module Apache
cat > /etc/utmstack-agent/beats/filebeat/modules.d/apache.yml <<'EOF'
- module: apache
  access:
    enabled: true
    var.paths: ["/var/log/utmstack-simulation/apache/access_log"]
  error:
    enabled: true
    var.paths: ["/var/log/utmstack-simulation/apache/error_log"]
EOF

# Module Nginx
cat > /etc/utmstack-agent/beats/filebeat/modules.d/nginx.yml <<'EOF'
- module: nginx
  access:
    enabled: true
    var.paths: ["/var/log/utmstack-simulation/nginx/access.log"]
  error:
    enabled: true
    var.paths: ["/var/log/utmstack-simulation/nginx/error.log"]
EOF

# Redémarrer l'agent
systemctl restart utmstack-agent

echo ""
echo -e "${GREEN}✅ Installation terminée !${NC}"
echo ""
echo "📊 Ports configurés :"
echo "   - 7014/UDP : Syslog (Cisco, Windows, AD, VPN, DNS, Proxy)"
echo "   - 7005/UDP : FortiGate"
echo ""
echo "📂 Logs stockés dans :"
echo "   - /var/log/utmstack-simulation/syslog.log"
echo "   - /var/log/utmstack-simulation/fortigate.log"
echo "   - /var/log/utmstack-simulation/nginx/"
echo "   - /var/log/utmstack-simulation/apache/"
echo ""
echo "🎯 Prochaines étapes :"
echo "   1. Copiez les fichiers dans $INSTALL_DIR"
echo "   2. cd $INSTALL_DIR"
echo "   3. docker-compose up -d"
echo ""
echo "📊 Dans UTMStack, activez les intégrations :"
echo "   - Syslog (port 7014)"
echo "   - FortiGate (port 7005)"
echo "   - Linux agent (déjà installé)"
