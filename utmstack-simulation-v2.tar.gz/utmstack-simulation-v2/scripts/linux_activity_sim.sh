#!/bin/bash
# Simulation d'activité serveur Linux

SERVER_NAME="${SERVER_NAME:-PROD-LINUX-SRV-01}"
SYSLOG_SERVER="${SYSLOG_SERVER:-172.18.0.1}"

echo "Starting Linux Server Activity Simulator: $SERVER_NAME"

# Configurer rsyslog pour envoyer au serveur UTMStack
cat > /etc/rsyslog.d/utmstack.conf <<EOF
*.* @${SYSLOG_SERVER}:514
EOF

# Redémarrer rsyslog
service rsyslog restart

# Générer des événements système aléatoires
while true; do
    # Événements SSH
    if [ $((RANDOM % 3)) -eq 0 ]; then
        logger -t sshd -p auth.info "Accepted password for user$(( RANDOM % 10 )) from 192.168.1.$((RANDOM % 254)) port $((RANDOM % 65535)) ssh2"
    else
        logger -t sshd -p auth.warning "Failed password for invalid user attacker from 203.0.113.$((RANDOM % 254)) port $((RANDOM % 65535)) ssh2"
    fi
    
    sleep $((RANDOM % 15 + 10))
    
    # Événements système
    EVENTS=(
        "systemd: Started Session \$((RANDOM % 1000)) of user root"
        "sudo: user1 : TTY=pts/0 ; PWD=/home/user1 ; USER=root ; COMMAND=/bin/ls"
        "kernel: [UFW BLOCK] IN=eth0 OUT= SRC=198.51.100.$((RANDOM % 254)) DST=192.168.1.10 PROTO=TCP DPT=22"
        "cron: (root) CMD (/usr/local/bin/backup.sh)"
        "systemd: apache2.service: Succeeded"
    )
    
    logger -p daemon.info "${EVENTS[$((RANDOM % ${#EVENTS[@]}))]}"
    
    sleep $((RANDOM % 20 + 10))
    
    # Événements de connexion utilisateur
    if [ $((RANDOM % 4)) -eq 0 ]; then
        logger -p auth.info "pam_unix(sudo:session): session opened for user root by (uid=1000)"
    fi
    
    sleep $((RANDOM % 25 + 15))
done
