#!/usr/bin/env python3
"""
Simulateur de logs Windows Server
Génère des événements Windows réalistes (Security, System, Application)
"""

import socket
import time
import random
import os
from datetime import datetime
import json

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
SERVER_NAME = os.getenv('SERVER_NAME', 'WIN-SRV-2022-01')
DOMAIN = os.getenv('DOMAIN', 'CORP.LOCAL')

def send_syslog(message, severity=6):
    """Envoie un événement Windows via syslog"""
    priority = 23 * 8 + severity
    timestamp = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{priority}>{timestamp} {SERVER_NAME} {message}"
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
        print(f"[SENT] Event ID in message")
    except Exception as e:
        print(f"[ERROR] {e}")

def generate_username():
    """Génère un nom d'utilisateur"""
    users = ['jdoe', 'asmith', 'bjohnson', 'mwilliams', 'administrator', 'svc_backup', 'attacker', 'scanner']
    return random.choice(users)

def generate_ip():
    """Génère une adresse IP"""
    return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def simulate_windows_events():
    """Simule des événements Windows"""
    
    windows_events = [
        # Événements de sécurité (Security Log)
        {
            'EventID': 4624,
            'Channel': 'Security',
            'Level': 'Information',
            'Message': 'An account was successfully logged on',
            'Severity': 6,
            'details': lambda: {
                'SubjectUserName': generate_username(),
                'TargetUserName': generate_username(),
                'LogonType': random.choice([2, 3, 7, 10]),  # 2=Interactive, 3=Network, 7=Unlock, 10=RemoteInteractive
                'IpAddress': generate_ip(),
                'WorkstationName': f'WKS-{random.randint(1, 100)}'
            }
        },
        {
            'EventID': 4625,
            'Channel': 'Security',
            'Level': 'Warning',
            'Message': 'An account failed to log on',
            'Severity': 4,
            'details': lambda: {
                'TargetUserName': generate_username(),
                'FailureReason': random.choice(['Unknown user name or bad password', 'Account locked out', 'Password expired']),
                'IpAddress': generate_ip(),
                'LogonType': 3
            }
        },
        {
            'EventID': 4648,
            'Channel': 'Security',
            'Level': 'Information',
            'Message': 'A logon was attempted using explicit credentials',
            'Severity': 6,
            'details': lambda: {
                'SubjectUserName': generate_username(),
                'TargetUserName': generate_username(),
                'TargetServerName': f'SERVER-{random.randint(1, 10)}',
                'IpAddress': generate_ip()
            }
        },
        {
            'EventID': 4720,
            'Channel': 'Security',
            'Level': 'Information',
            'Message': 'A user account was created',
            'Severity': 5,
            'details': lambda: {
                'TargetUserName': f'user_{random.randint(1000, 9999)}',
                'SubjectUserName': 'administrator'
            }
        },
        {
            'EventID': 4728,
            'Channel': 'Security',
            'Level': 'Information',
            'Message': 'A member was added to a security-enabled global group',
            'Severity': 5,
            'details': lambda: {
                'MemberName': generate_username(),
                'TargetUserName': random.choice(['Domain Admins', 'Enterprise Admins', 'Administrators', 'Users'])
            }
        },
        {
            'EventID': 4740,
            'Channel': 'Security',
            'Level': 'Warning',
            'Message': 'A user account was locked out',
            'Severity': 4,
            'details': lambda: {
                'TargetUserName': generate_username(),
                'SubjectUserName': 'SYSTEM',
                'CallerComputer': f'WKS-{random.randint(1, 100)}'
            }
        },
        # Événements Sysmon
        {
            'EventID': 1,
            'Channel': 'Microsoft-Windows-Sysmon/Operational',
            'Level': 'Information',
            'Message': 'Process Create',
            'Severity': 6,
            'details': lambda: {
                'Image': random.choice(['C:\\Windows\\System32\\cmd.exe', 'C:\\Windows\\System32\\powershell.exe', 
                                       'C:\\Windows\\System32\\net.exe', 'C:\\Program Files\\Chrome\\chrome.exe']),
                'CommandLine': random.choice(['cmd.exe /c "whoami"', 'powershell.exe -enc BASE64STRING', 
                                             'net user /domain', 'ipconfig /all']),
                'User': f'{DOMAIN}\\{generate_username()}',
                'ParentImage': 'C:\\Windows\\explorer.exe'
            }
        },
        {
            'EventID': 3,
            'Channel': 'Microsoft-Windows-Sysmon/Operational',
            'Level': 'Information',
            'Message': 'Network connection detected',
            'Severity': 6,
            'details': lambda: {
                'Image': random.choice(['C:\\Windows\\System32\\svchost.exe', 'C:\\Program Files\\Chrome\\chrome.exe']),
                'SourceIp': generate_ip(),
                'DestinationIp': generate_ip(),
                'DestinationPort': random.choice([80, 443, 445, 3389, 22]),
                'Protocol': 'tcp'
            }
        },
        # Événements système
        {
            'EventID': 7045,
            'Channel': 'System',
            'Level': 'Information',
            'Message': 'A service was installed in the system',
            'Severity': 5,
            'details': lambda: {
                'ServiceName': f'Service{random.randint(1, 100)}',
                'ServiceType': 'user mode service',
                'StartType': random.choice(['auto start', 'demand start', 'disabled'])
            }
        }
    ]
    
    print(f"Starting Windows Server Simulator: {SERVER_NAME}")
    print(f"Domain: {DOMAIN}")
    print(f"Sending logs to {SYSLOG_SERVER}:{SYSLOG_PORT}")
    
    while True:
        event = random.choice(windows_events)
        details = event['details']()
        
        # Format message Windows Event
        message = (
            f"EventID={event['EventID']} "
            f"Channel={event['Channel']} "
            f"Computer={SERVER_NAME}.{DOMAIN} "
            f"Level={event['Level']} "
            f"Message=\"{event['Message']}\" "
        )
        
        # Ajouter les détails
        for key, value in details.items():
            message += f"{key}=\"{value}\" "
        
        send_syslog(message, severity=event['Severity'])
        
        # Événements de connexion plus fréquents, autres moins
        if event['EventID'] in [4624, 4625]:
            time.sleep(random.randint(10, 30))
        else:
            time.sleep(random.randint(30, 120))

if __name__ == '__main__':
    try:
        simulate_windows_events()
    except KeyboardInterrupt:
        print("\nSimulator stopped")
