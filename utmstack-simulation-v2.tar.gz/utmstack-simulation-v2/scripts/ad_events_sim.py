#!/usr/bin/env python3
"""
Simulateur Active Directory
Génère des événements AD réalistes
"""

import socket
import time
import random
import os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
DC_NAME = os.getenv('DC_NAME', 'DC01')
DOMAIN = os.getenv('DOMAIN', 'CORP.LOCAL')

def send_syslog(message, severity=6):
    priority = 23 * 8 + severity
    timestamp = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{priority}>{timestamp} {DC_NAME}.{DOMAIN} {message}"
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
        print(f"[SENT] AD Event")
    except Exception as e:
        print(f"[ERROR] {e}")

def generate_username():
    return random.choice(['jdoe', 'asmith', 'bjohnson', 'mwilliams', 'admin', 'svc_backup', 'attacker'])

def generate_ip():
    return f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"

def simulate_ad_events():
    ad_events = [
        {
            'EventID': 4662,
            'Message': 'An operation was performed on an object',
            'Severity': 6,
            'details': lambda: {
                'SubjectUserName': generate_username(),
                'ObjectName': f'CN={generate_username()},OU=Users,DC=CORP,DC=LOCAL',
                'OperationType': random.choice(['Read', 'Write', 'Delete']),
                'AccessList': random.choice(['Read All Properties', 'Write All Properties', 'Delete'])
            }
        },
        {
            'EventID': 4742,
            'Message': 'A computer account was changed',
            'Severity': 5,
            'details': lambda: {
                'TargetUserName': f'COMP{random.randint(1, 100)}$',
                'SubjectUserName': generate_username()
            }
        },
        {
            'EventID': 5136,
            'Message': 'A directory service object was modified',
            'Severity': 5,
            'details': lambda: {
                'SubjectUserName': generate_username(),
                'ObjectDN': f'CN={generate_username()},OU=Users,DC=CORP,DC=LOCAL',
                'AttributeLDAPDisplayName': random.choice(['memberOf', 'userAccountControl', 'pwdLastSet']),
                'OperationType': random.choice(['%%14674', '%%14675'])  # Value Added/Deleted
            }
        },
        {
            'EventID': 4776,
            'Message': 'The domain controller attempted to validate the credentials for an account',
            'Severity': random.choice([4, 6]),
            'details': lambda: {
                'TargetUserName': generate_username(),
                'Workstation': f'WKS-{random.randint(1, 100)}',
                'Status': random.choice(['0x0', '0xC0000064', '0xC000006A'])  # Success, Bad username, Bad password
            }
        },
        {
            'EventID': 4771,
            'Message': 'Kerberos pre-authentication failed',
            'Severity': 4,
            'details': lambda: {
                'TargetUserName': generate_username(),
                'IpAddress': generate_ip(),
                'FailureCode': random.choice(['0x18', '0x6', '0x12'])
            }
        }
    ]
    
    print(f"Starting Active Directory Simulator: {DC_NAME}.{DOMAIN}")
    print(f"Sending logs to {SYSLOG_SERVER}:{SYSLOG_PORT}")
    
    while True:
        event = random.choice(ad_events)
        details = event['details']()
        
        message = (
            f"EventID={event['EventID']} "
            f"Computer={DC_NAME}.{DOMAIN} "
            f"Channel=Security "
            f"Message=\"{event['Message']}\" "
        )
        
        for key, value in details.items():
            message += f"{key}=\"{value}\" "
        
        send_syslog(message, severity=event['Severity'])
        time.sleep(random.randint(15, 60))

if __name__ == '__main__':
    try:
        simulate_ad_events()
    except KeyboardInterrupt:
        print("\nSimulator stopped")
