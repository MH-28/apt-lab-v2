#!/usr/bin/env python3
"""Simulateur DNS"""
import socket, time, random, os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
DNS_NAME = os.getenv('DNS_SERVER_NAME', 'DNS-01')

def send_syslog(msg, sev=6):
    pri = 23 * 8 + sev
    ts = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{pri}>{ts} {DNS_NAME} {msg}"
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
    except: pass

def gen_ip():
    return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def simulate_dns():
    domains = [
        'google.com', 'microsoft.com', 'github.com', 'stackoverflow.com',
        'malicious-site.ru', 'phishing-bank.com', 'c2-server.xyz',
        'legitimate-corp.com', 'mail.company.local'
    ]
    
    print(f"Starting DNS Simulator: {DNS_NAME}")
    
    while True:
        client = gen_ip()
        domain = random.choice(domains)
        qtype = random.choice(['A', 'AAAA', 'MX', 'TXT', 'CNAME'])
        
        if 'malicious' in domain or 'phishing' in domain or 'c2' in domain:
            msg = f"client={client} query={domain} qtype={qtype} response=NXDOMAIN category=BLOCKED_MALICIOUS"
            send_syslog(msg, 4)
        else:
            msg = f"client={client} query={domain} qtype={qtype} response={gen_ip()} rtt={random.randint(1, 50)}ms"
            send_syslog(msg, 6)
        
        time.sleep(random.randint(1, 10))

if __name__ == '__main__':
    try:
        simulate_dns()
    except KeyboardInterrupt:
        print("\nStopped")
