#!/usr/bin/env python3
"""
Dashboard de monitoring des simulateurs
Interface web simple pour voir l'état des simulateurs
"""

from flask import Flask, render_template_string
import subprocess
import json

app = Flask(__name__)

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>UTMStack Log Simulators Dashboard</title>
    <meta http-equiv="refresh" content="30">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #1a1a2e;
            color: #eee;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        h1 {
            color: #00d4ff;
            text-align: center;
            margin-bottom: 30px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .card {
            background: #16213e;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 212, 255, 0.1);
        }
        .card h2 {
            color: #00d4ff;
            font-size: 18px;
            margin: 0 0 15px 0;
            display: flex;
            align-items: center;
        }
        .status {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 10px;
        }
        .status.running { background: #00ff00; }
        .status.stopped { background: #ff4444; }
        .info {
            font-size: 14px;
            line-height: 1.6;
            color: #bbb;
        }
        .info strong {
            color: #00d4ff;
        }
        .stats {
            background: #0f1419;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            text-align: center;
        }
        .stat-box {
            background: #16213e;
            padding: 15px;
            border-radius: 8px;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #00d4ff;
        }
        .stat-label {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 UTMStack Log Simulation Environment</h1>
        
        <div class="stats">
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-number">{{ running_count }}</div>
                    <div class="stat-label">RUNNING SIMULATORS</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number">{{ total_count }}</div>
                    <div class="stat-label">TOTAL SIMULATORS</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number">~{{ logs_per_min }}</div>
                    <div class="stat-label">LOGS/MINUTE</div>
                </div>
            </div>
        </div>
        
        <div class="grid">
            {% for sim in simulators %}
            <div class="card">
                <h2>
                    <span class="status {{ sim.status }}"></span>
                    {{ sim.name }}
                </h2>
                <div class="info">
                    <strong>Type:</strong> {{ sim.type }}<br>
                    <strong>Container:</strong> {{ sim.container }}<br>
                    <strong>IP:</strong> {{ sim.ip }}<br>
                    <strong>Status:</strong> {{ sim.status }}<br>
                    <strong>Description:</strong> {{ sim.description }}
                </div>
            </div>
            {% endfor %}
        </div>
        
        <div style="text-align: center; margin-top: 40px; color: #666;">
            Auto-refresh every 30 seconds | UTMStack Server: 172.18.0.1:514
        </div>
    </div>
</body>
</html>
'''

def get_container_status():
    """Récupère l'état des conteneurs"""
    try:
        result = subprocess.run(
            ['docker', 'ps', '--format', '{{.Names}}\t{{.Status}}\t{{.Networks}}'],
            capture_output=True, text=True
        )
        containers = {}
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('\t')
                if len(parts) >= 2:
                    containers[parts[0]] = {
                        'status': 'running' if 'Up' in parts[1] else 'stopped',
                        'details': parts[1]
                    }
        return containers
    except:
        return {}

@app.route('/')
def dashboard():
    containers = get_container_status()
    
    simulators = [
        {
            'name': 'Cisco Switch',
            'type': 'Network Device',
            'container': 'sim_cisco_switch',
            'ip': '172.30.1.10',
            'description': 'Simulates Cisco IOS switch events (port up/down, BPDU, security violations)',
            'status': containers.get('sim_cisco_switch', {}).get('status', 'stopped')
        },
        {
            'name': 'Cisco Router',
            'type': 'Network Device',
            'container': 'sim_cisco_router',
            'ip': '172.30.1.20',
            'description': 'Simulates Cisco IOS router events (BGP, OSPF, ACL denies, login attempts)',
            'status': containers.get('sim_cisco_router', {}).get('status', 'stopped')
        },
        {
            'name': 'FortiGate Firewall',
            'type': 'Security Device',
            'container': 'sim_fortigate',
            'ip': '172.30.2.10',
            'description': 'Simulates FortiOS firewall logs (traffic, UTM, IPS, antivirus)',
            'status': containers.get('sim_fortigate', {}).get('status', 'stopped')
        },
        {
            'name': 'Nginx Web Server',
            'type': 'Application',
            'container': 'sim_nginx_web',
            'ip': '172.30.3.10',
            'description': 'Real Nginx server with access logs (includes attack simulations)',
            'status': containers.get('sim_nginx_web', {}).get('status', 'stopped')
        },
        {
            'name': 'Apache Web Server',
            'type': 'Application',
            'container': 'sim_apache_web',
            'ip': '172.30.3.20',
            'description': 'Real Apache HTTP server with access and error logs',
            'status': containers.get('sim_apache_web', {}).get('status', 'stopped')
        },
        {
            'name': 'MySQL Database',
            'type': 'Database',
            'container': 'sim_mysql_db',
            'ip': '172.30.4.10',
            'description': 'MySQL 8.0 with query logging enabled',
            'status': containers.get('sim_mysql_db', {}).get('status', 'stopped')
        },
        {
            'name': 'Linux Server',
            'type': 'Operating System',
            'container': 'sim_linux_server',
            'ip': '172.30.5.10',
            'description': 'Ubuntu server with SSH, sudo, and system event logs',
            'status': containers.get('sim_linux_server', {}).get('status', 'stopped')
        },
        {
            'name': 'Windows Server',
            'type': 'Operating System',
            'container': 'sim_windows_server',
            'ip': '172.30.5.20',
            'description': 'Simulates Windows Security events and Sysmon events',
            'status': containers.get('sim_windows_server', {}).get('status', 'stopped')
        },
        {
            'name': 'Active Directory',
            'type': 'Identity Management',
            'container': 'sim_active_directory',
            'ip': '172.30.5.30',
            'description': 'Simulates AD events (authentication, Kerberos, object modifications)',
            'status': containers.get('sim_active_directory', {}).get('status', 'stopped')
        },
        {
            'name': 'VPN Gateway',
            'type': 'Remote Access',
            'container': 'sim_vpn_server',
            'ip': '172.30.6.10',
            'description': 'Simulates OpenVPN connection/disconnection events',
            'status': containers.get('sim_vpn_server', {}).get('status', 'stopped')
        },
        {
            'name': 'Proxy Server',
            'type': 'Web Proxy',
            'container': 'sim_proxy_squid',
            'ip': '172.30.6.20',
            'description': 'Simulates Squid proxy access logs (HTTP/HTTPS traffic)',
            'status': containers.get('sim_proxy_squid', {}).get('status', 'stopped')
        },
        {
            'name': 'DNS Server',
            'type': 'Network Service',
            'container': 'sim_dns_server',
            'ip': '172.30.7.10',
            'description': 'Simulates DNS query logs (including malicious domain blocks)',
            'status': containers.get('sim_dns_server', {}).get('status', 'stopped')
        }
    ]
    
    running_count = sum(1 for s in simulators if s['status'] == 'running')
    total_count = len(simulators)
    logs_per_min = running_count * 4  # Estimation
    
    return render_template_string(
        HTML_TEMPLATE,
        simulators=simulators,
        running_count=running_count,
        total_count=total_count,
        logs_per_min=logs_per_min
    )

if __name__ == '__main__':
    print("Starting Monitoring Dashboard on http://0.0.0.0:5000")
    app.run(host='0.0.0.0', port=5000, debug=False)
