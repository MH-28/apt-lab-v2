#!/usr/bin/env python3
"""
Simulateur de logs Cisco Switch
Génère des logs réalistes de switch Cisco IOS
"""

import socket
import time
import random
import os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
DEVICE_NAME = os.getenv('DEVICE_NAME', 'CORE-SW-01')

# Templates de logs Cisco Switch
LOG_TEMPLATES = [
    "%LINEPROTO-5-UPDOWN: Line protocol on Interface GigabitEthernet{port}, changed state to {state}",
    "%LINK-3-UPDOWN: Interface GigabitEthernet{port}, changed state to {state}",
    "%SYS-5-CONFIG_I: Configured from console by {user} on vty0 (192.168.1.{ip})",
    "%AUTHMGR-5-SUCCESS: Authorization succeeded for client ({mac}) on Interface Gi{port}",
    "%DOT1X-5-SUCCESS: Authentication successful for client {mac} on Interface Gi{port}",
    "%LINK-3-UPDOWN: Interface Vlan{vlan}, changed state to {state}",
    "%SPANTREE-2-BLOCK_BPDUGUARD: Received BPDU on port Gi{port} with BPDU Guard enabled. Disabling port.",
    "%PLATFORM-2-FAN_ERROR: Fan {fan_num} has failed",
    "%PLATFORM-5-FAN_OK: Fan {fan_num} is operating normally",
    "%PORT_SECURITY-2-PSECURE_VIOLATION: Security violation occurred, caused by MAC {mac} on port Gi{port}",
    "%CDP-4-DUPLEX_MISMATCH: duplex mismatch discovered on Gi{port}",
    "%STP-2-LOOPGUARD_BLOCK: Loop guard blocking port Gi{port} on VLAN{vlan}",
]

def send_syslog(message, severity=5, facility=23):
    """Envoie un message syslog au serveur UTMStack"""
    priority = facility * 8 + severity
    timestamp = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{priority}>{timestamp} {DEVICE_NAME} {message}"
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
        print(f"[SENT] {syslog_msg}")
    except Exception as e:
        print(f"[ERROR] Failed to send syslog: {e}")

def generate_mac():
    """Génère une adresse MAC aléatoire"""
    return ':'.join([f'{random.randint(0, 255):02x}' for _ in range(6)])

def simulate_switch_events():
    """Simule des événements de switch Cisco"""
    print(f"Starting Cisco Switch Simulator: {DEVICE_NAME}")
    print(f"Sending logs to {SYSLOG_SERVER}:{SYSLOG_PORT}")
    
    while True:
        # Sélectionner un template aléatoire
        template = random.choice(LOG_TEMPLATES)
        
        # Remplir les variables
        log_message = template.format(
            port=f"0/{random.randint(1, 48)}",
            state=random.choice(['up', 'down']),
            user=random.choice(['admin', 'netadmin', 'operator']),
            ip=random.randint(1, 254),
            mac=generate_mac(),
            vlan=random.randint(10, 100),
            fan_num=random.randint(1, 4)
        )
        
        # Déterminer la sévérité selon le message
        if 'ERROR' in template or 'FAIL' in template:
            severity = 3  # Error
        elif 'SUCCESS' in template or 'OK' in template:
            severity = 5  # Notice
        elif 'WARNING' in template:
            severity = 4  # Warning
        else:
            severity = 6  # Informational
        
        send_syslog(log_message, severity=severity)
        
        # Attendre entre 5 et 30 secondes avant le prochain événement
        time.sleep(random.randint(5, 30))

if __name__ == '__main__':
    try:
        simulate_switch_events()
    except KeyboardInterrupt:
        print("\nSimulator stopped by user")
