#!/usr/bin/env python3
"""
Simulateur VPN (OpenVPN-like)
"""
import socket, time, random, os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
VPN_NAME = os.getenv('VPN_SERVER_NAME', 'VPN-GATEWAY-01')

def send_syslog(msg, sev=6):
    pri = 23 * 8 + sev
    ts = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{pri}>{ts} {VPN_NAME} {msg}"
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
        print(f"[VPN] {msg}")
    except Exception as e:
        print(f"[ERROR] {e}")

def gen_ip():
    return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def simulate_vpn():
    users = ['jdoe', 'asmith', 'remote_user', 'contractor']
    print(f"Starting VPN Simulator: {VPN_NAME}")
    
    while True:
        action = random.choice(['connect', 'disconnect', 'auth_fail'])
        user = random.choice(users)
        pub_ip = gen_ip()
        vpn_ip = f"10.8.0.{random.randint(2, 254)}"
        
        if action == 'connect':
            msg = f"USER={user} PUBLIC_IP={pub_ip} VPN_IP={vpn_ip} ACTION=CONNECTION_ESTABLISHED PROTOCOL=UDP CIPHER=AES-256-GCM"
            send_syslog(msg, 5)
        elif action == 'disconnect':
            msg = f"USER={user} VPN_IP={vpn_ip} ACTION=DISCONNECTED BYTES_SENT={random.randint(1000000, 10000000)} BYTES_RECV={random.randint(1000000, 10000000)}"
            send_syslog(msg, 6)
        else:
            msg = f"USER={user} PUBLIC_IP={pub_ip} ACTION=AUTH_FAILED REASON=Bad_Password"
            send_syslog(msg, 4)
        
        time.sleep(random.randint(20, 90))

if __name__ == '__main__':
    try:
        simulate_vpn()
    except KeyboardInterrupt:
        print("\nStopped")
