#!/usr/bin/env python3
"""
Simulateur de logs Cisco Router
Génère des logs réalistes de routeur Cisco IOS
"""

import socket
import time
import random
import os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
DEVICE_NAME = os.getenv('DEVICE_NAME', 'EDGE-RTR-01')

# Templates de logs Cisco Router
LOG_TEMPLATES = [
    "%LINEPROTO-5-UPDOWN: Line protocol on Interface GigabitEthernet{port}, changed state to {state}",
    "%LINK-3-UPDOWN: Interface GigabitEthernet{port}, changed state to {state}",
    "%SYS-5-CONFIG_I: Configured from console by {user} on vty{vty}",
    "%SEC_LOGIN-5-LOGIN_SUCCESS: Login Success [user: {user}] [Source: {src_ip}] at {time}",
    "%SEC_LOGIN-4-LOGIN_FAILED: Login failed [user: {user}] [Source: {src_ip}] [Reason: Invalid password] at {time}",
    "%BGP-5-ADJCHANGE: neighbor {neighbor_ip} Up",
    "%BGP-3-NOTIFICATION: sent to neighbor {neighbor_ip} {reason}",
    "%OSPF-5-ADJCHG: Process {process}, Nbr {neighbor_ip} on {interface} from LOADING to FULL",
    "%HSRP-5-STATECHANGE: Standby: {group}: {interface} state Standby -> Active",
    "%CRYPTO-4-PKT_REPLAY_ERR: decrypt: replay check failed connection id={conn_id}",
    "%IPSEC-4-IKMP_NO_SA: IKE: Received IPSec packet from {remote_ip} with no SA",
    "%ACL-4-DENY: list {acl_name} denied {protocol} {src_ip}({src_port}) -> {dst_ip}({dst_port}), {count} packet(s)",
]

def send_syslog(message, severity=5, facility=23):
    """Envoie un message syslog"""
    priority = facility * 8 + severity
    timestamp = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{priority}>{timestamp} {DEVICE_NAME} {message}"
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
        print(f"[SENT] {syslog_msg}")
    except Exception as e:
        print(f"[ERROR] {e}")

def generate_ip():
    """Génère une IP aléatoire"""
    return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def simulate_router_events():
    """Simule des événements de routeur"""
    print(f"Starting Cisco Router Simulator: {DEVICE_NAME}")
    print(f"Sending logs to {SYSLOG_SERVER}:{SYSLOG_PORT}")
    
    while True:
        template = random.choice(LOG_TEMPLATES)
        
        log_message = template.format(
            port=f"0/{random.randint(0, 3)}",
            state=random.choice(['up', 'down']),
            user=random.choice(['admin', 'netadmin', 'readonly', 'attacker']),
            vty=random.randint(0, 4),
            src_ip=generate_ip(),
            time=datetime.now().strftime('%H:%M:%S UTC %b %d %Y'),
            neighbor_ip=generate_ip(),
            reason=random.choice(['Connection reset', 'Hold Timer Expired', 'Admin shutdown']),
            process=random.randint(1, 10),
            interface=f"GigabitEthernet0/{random.randint(0, 3)}",
            group=random.randint(1, 10),
            conn_id=random.randint(1000, 9999),
            remote_ip=generate_ip(),
            acl_name=random.choice(['OUTSIDE_IN', 'INSIDE_OUT', 'DMZ_FILTER']),
            protocol=random.choice(['tcp', 'udp', 'icmp']),
            src_port=random.randint(1024, 65535),
            dst_ip=generate_ip(),
            dst_port=random.choice([22, 23, 80, 443, 3389, 445, 21]),
            count=random.randint(1, 100)
        )
        
        if 'FAILED' in template or 'DENY' in template or 'ERR' in template:
            severity = 4
        elif 'SUCCESS' in template or 'UP' in template:
            severity = 5
        else:
            severity = 6
        
        send_syslog(log_message, severity=severity)
        time.sleep(random.randint(8, 40))

if __name__ == '__main__':
    try:
        simulate_router_events()
    except KeyboardInterrupt:
        print("\nSimulator stopped")
