#!/usr/bin/env python3
"""Simulateur Proxy Squid"""
import socket, time, random, os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
PROXY_NAME = os.getenv('PROXY_NAME', 'PROXY-01')

def send_syslog(msg, sev=6):
    pri = 23 * 8 + sev
    ts = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{pri}>{ts} {PROXY_NAME} {msg}"
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
    except: pass

def gen_ip():
    return f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"

def simulate_proxy():
    urls = [
        'http://www.google.com/', 'https://github.com/repo',
        'http://malware-download.xyz/payload.exe', 'https://legitimate-site.com/',
        'http://social-media.com/', 'https://streaming-site.tv/video'
    ]
    
    methods = ['GET', 'POST', 'CONNECT']
    status_codes = [200, 301, 302, 403, 404, 500]
    
    print(f"Starting Proxy Simulator: {PROXY_NAME}")
    
    while True:
        timestamp = int(time.time())
        client_ip = gen_ip()
        method = random.choice(methods)
        url = random.choice(urls)
        status = random.choice(status_codes)
        bytes_sent = random.randint(100, 1000000)
        
        # Format Squid access log
        log = f"{timestamp}.{random.randint(100, 999)} {random.randint(10, 500)} {client_ip} TCP_MISS/{status} {bytes_sent} {method} {url} - DIRECT/{gen_ip()} text/html"
        
        send_syslog(log, 6)
        time.sleep(random.randint(2, 8))

if __name__ == '__main__':
    try:
        simulate_proxy()
    except KeyboardInterrupt:
        print("\nStopped")
