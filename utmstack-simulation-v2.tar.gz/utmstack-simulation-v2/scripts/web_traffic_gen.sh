#!/bin/sh
# Générateur de trafic Web pour tester Nginx/Apache

echo "Starting Web Traffic Generator..."

while true; do
    # Générer différents types de requêtes
    curl -s http://172.30.3.10/ > /dev/null
    sleep $((RANDOM % 5 + 1))
    
    curl -s http://172.30.3.10/api/users > /dev/null
    sleep $((RANDOM % 5 + 1))
    
    curl -s http://172.30.3.10/login -X POST -d "user=admin&pass=test" > /dev/null
    sleep $((RANDOM % 5 + 1))
    
    # Simuler des attaques
    curl -s "http://172.30.3.10/admin.php?id=1' OR '1'='1" > /dev/null  # SQL Injection
    sleep $((RANDOM % 10 + 1))
    
    curl -s "http://172.30.3.10/search?q=<script>alert('xss')</script>" > /dev/null  # XSS
    sleep $((RANDOM % 15 + 1))
    
    # Requêtes normales variées
    curl -s http://172.30.3.10/products > /dev/null
    curl -s http://172.30.3.10/contact > /dev/null
    curl -s http://172.30.3.10/about > /dev/null
    
    sleep $((RANDOM % 10 + 5))
done
