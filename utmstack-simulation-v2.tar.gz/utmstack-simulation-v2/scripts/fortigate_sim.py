#!/usr/bin/env python3
"""
Simulateur de logs FortiGate Firewall
Génère des logs réalistes FortiOS
"""

import socket
import time
import random
import os
from datetime import datetime

SYSLOG_SERVER = os.getenv('SYSLOG_SERVER', '172.18.0.1')
SYSLOG_PORT = int(os.getenv('SYSLOG_PORT', 514))
DEVICE_NAME = os.getenv('DEVICE_NAME', 'FGT-PERIMETER-01')
VDOM = os.getenv('VDOM', 'root')

def send_syslog(message, severity=5):
    """Envoie un message syslog FortiGate"""
    priority = 23 * 8 + severity
    timestamp = datetime.now().strftime('%b %d %H:%M:%S')
    syslog_msg = f"<{priority}>{timestamp} {DEVICE_NAME} {message}"
    
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(syslog_msg.encode('utf-8'), (SYSLOG_SERVER, SYSLOG_PORT))
        sock.close()
        print(f"[SENT] {syslog_msg}")
    except Exception as e:
        print(f"[ERROR] {e}")

def generate_ip():
    return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def generate_mac():
    return ':'.join([f'{random.randint(0, 255):02x}' for _ in range(6)])

def simulate_fortigate_traffic():
    """Simule du trafic FortiGate"""
    
    traffic_types = [
        {
            'type': 'traffic',
            'subtype': 'forward',
            'action': 'accept',
            'policyid': random.randint(1, 100),
            'service': random.choice(['HTTP', 'HTTPS', 'SSH', 'RDP', 'FTP', 'SMTP', 'DNS']),
            'proto': 6,
            'srcport': random.randint(1024, 65535),
            'dstport': random.choice([80, 443, 22, 3389, 21, 25, 53])
        },
        {
            'type': 'traffic',
            'subtype': 'forward',
            'action': 'deny',
            'policyid': 0,
            'service': 'tcp/' + str(random.choice([445, 135, 139, 1433, 3306])),
            'proto': 6,
            'srcport': random.randint(1024, 65535),
            'dstport': random.choice([445, 135, 139, 1433, 3306])
        },
        {
            'type': 'utm',
            'subtype': 'virus',
            'action': 'blocked',
            'virus': random.choice(['Trojan.Win32.Generic', 'Ransomware.WannaCry', 'Backdoor.Agent']),
            'service': 'HTTP'
        },
        {
            'type': 'utm',
            'subtype': 'ips',
            'action': 'detected',
            'attack': random.choice(['SQL.Injection', 'XSS.Attack', 'Buffer.Overflow', 'Brute.Force.Login']),
            'service': 'HTTPS'
        },
        {
            'type': 'utm',
            'subtype': 'webfilter',
            'action': 'blocked',
            'category': random.choice(['Malicious.Websites', 'Phishing', 'Adult.Content', 'P2P']),
            'service': 'HTTP'
        }
    ]
    
    print(f"Starting FortiGate Simulator: {DEVICE_NAME}")
    print(f"Sending logs to {SYSLOG_SERVER}:{SYSLOG_PORT}")
    
    while True:
        event = random.choice(traffic_types)
        
        srcip = generate_ip()
        dstip = generate_ip()
        srcintf = random.choice(['port1', 'port2', 'wan1', 'dmz'])
        dstintf = random.choice(['port3', 'port4', 'internal', 'dmz'])
        
        if event['type'] == 'traffic':
            log_msg = (
                f"date={datetime.now().strftime('%Y-%m-%d')} time={datetime.now().strftime('%H:%M:%S')} "
                f"devname=\"{DEVICE_NAME}\" devid=\"FGT60E123456789\" "
                f"logid=\"0000000013\" type=\"{event['type']}\" subtype=\"{event['subtype']}\" "
                f"level=\"notice\" vd=\"{VDOM}\" "
                f"eventtime={int(time.time())} "
                f"srcip={srcip} srcport={event['srcport']} "
                f"srcintf=\"{srcintf}\" srcintfrole=\"wan\" "
                f"dstip={dstip} dstport={event['dstport']} "
                f"dstintf=\"{dstintf}\" dstintfrole=\"lan\" "
                f"policyid={event['policyid']} policytype=\"policy\" "
                f"service=\"{event['service']}\" proto={event['proto']} "
                f"action=\"{event['action']}\" "
                f"sentbyte={random.randint(100, 1000000)} rcvdbyte={random.randint(100, 1000000)} "
                f"sentpkt={random.randint(1, 1000)} rcvdpkt={random.randint(1, 1000)} "
                f"sessionid={random.randint(100000, 999999)}"
            )
        else:  # UTM events
            log_msg = (
                f"date={datetime.now().strftime('%Y-%m-%d')} time={datetime.now().strftime('%H:%M:%S')} "
                f"devname=\"{DEVICE_NAME}\" devid=\"FGT60E123456789\" "
                f"logid=\"0100032001\" type=\"{event['type']}\" subtype=\"{event['subtype']}\" "
                f"level=\"warning\" vd=\"{VDOM}\" "
                f"eventtime={int(time.time())} "
                f"srcip={srcip} dstip={dstip} "
                f"srcintf=\"{srcintf}\" dstintf=\"{dstintf}\" "
                f"policyid={random.randint(1, 100)} "
                f"service=\"{event['service']}\" "
                f"action=\"{event['action']}\" "
            )
            if event['subtype'] == 'virus':
                log_msg += f"virus=\"{event['virus']}\" "
            elif event['subtype'] == 'ips':
                log_msg += f"attack=\"{event['attack']}\" "
            elif event['subtype'] == 'webfilter':
                log_msg += f"category=\"{event['category']}\" "
        
        severity = 4 if event['action'] in ['deny', 'blocked', 'detected'] else 6
        send_syslog(log_msg, severity=severity)
        
        time.sleep(random.randint(3, 15))

if __name__ == '__main__':
    try:
        simulate_fortigate_traffic()
    except KeyboardInterrupt:
        print("\nSimulator stopped")
