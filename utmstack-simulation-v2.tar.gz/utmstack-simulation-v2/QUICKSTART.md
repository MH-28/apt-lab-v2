# 🚀 GUIDE RAPIDE - Environnement de Simulation UTMStack v11

## ⚡ Installation en 3 étapes

### Étape 1 : Préparer le serveur

```bash
# Sur votre serveur UTMStack
cd /opt
tar -xzf utmstack-simulation-v2.tar.gz
cd utmstack-simulation-v2
```

### Étape 2 : Installer

```bash
chmod +x install.sh
./install.sh
```

Le script va automatiquement :
- ✅ Configurer rsyslog sur ports 7014 et 7005
- ✅ Ouvrir les ports firewall
- ✅ Installer l'Agent UTMStack
- ✅ Configurer Filebeat pour Apache/Nginx
- ✅ Créer les dossiers de logs

### Étape 3 : Démarrer les simulateurs

```bash
docker-compose up -d
```

---

## 📊 Activer les intégrations dans UTMStack

### 1. Activer Syslog (Port 7014)

1. Ouvrir `http://10.10.1.230:8888`
2. Aller dans **Integrations** > **Syslog**
3. Cliquer **Enable**
4. Configuration :
   - Platform : **Linux**
   - Protocol : **UDP**
   - Action : **Listen**
5. Cliquer **Activate**

### 2. Activer FortiGate (Port 7005)

1. Aller dans **Integrations** > **FortiGate**
2. Cliquer **Enable**
3. Configuration :
   - Platform : **Linux**
   - Protocol : **UDP**
   - Action : **Listen**
4. Cliquer **Activate**

### 3. Vérifier l'Agent Linux

1. Aller dans **Data Sources** > **Agents**
2. Vous devriez voir l'agent du serveur
3. Vérifier que les modules **Apache** et **Nginx** sont actifs

---

## 🧪 Tests rapides

### Test 1 : Vérifier que les ports écoutent

```bash
netstat -uln | grep -E "7014|7005"
```

Résultat attendu :
```
udp   0  0  10.10.1.230:7014   0.0.0.0:*
udp   0  0  10.10.1.230:7005   0.0.0.0:*
```

### Test 2 : Vérifier les simulateurs

```bash
docker-compose ps
```

Tous les conteneurs doivent être "Up"

### Test 3 : Envoyer un log de test

```bash
# Test FortiGate (port 7005)
echo "<134>$(date '+%b %d %H:%M:%S') FGT-TEST type=traffic action=accept" | nc -u 10.10.1.230 7005

# Test Syslog (port 7014)
echo "<134>$(date '+%b %d %H:%M:%S') CORE-SW-01 TEST: Interface up" | nc -u 10.10.1.230 7014
```

### Test 4 : Vérifier les logs reçus

```bash
# Logs FortiGate
tail -f /var/log/utmstack-simulation/fortigate.log

# Logs Syslog général
tail -f /var/log/utmstack-simulation/syslog.log
```

### Test 5 : Vérifier dans UTMStack

1. Aller dans **Log Explorer**
2. Rechercher : `FGT-PERIMETER-01` ou `CORE-SW-01`
3. Vous devriez voir les logs arriver en temps réel !

---

## 📋 Simulateurs actifs

| Simulateur | Port | IP Source | Logs/min |
|------------|------|-----------|----------|
| FortiGate | 7005 UDP | 172.30.2.10 | ~6 |
| Cisco Switch | 7014 UDP | 172.30.1.10 | ~4 |
| Cisco Router | 7014 UDP | 172.30.1.20 | ~3 |
| Windows Server | 7014 UDP | 172.30.5.20 | ~5 |
| Active Directory | 7014 UDP | 172.30.5.30 | ~3 |
| VPN Gateway | 7014 UDP | 172.30.6.10 | ~2 |
| DNS Server | 7014 UDP | 172.30.7.10 | ~8 |
| Proxy Squid | 7014 UDP | 172.30.6.20 | ~6 |
| Nginx | Agent | 172.30.3.10 | ~8 |
| Apache | Agent | 172.30.3.20 | ~4 |

**Total : ~50 logs/minute**

---

## 🎯 Commandes utiles

```bash
# Voir les logs en temps réel des simulateurs
docker-compose logs -f | grep SENT

# Voir uniquement FortiGate
docker-compose logs -f fortigate_simulator

# Redémarrer tous les simulateurs
docker-compose restart

# Arrêter tout
docker-compose down

# Redémarrer tout
docker-compose up -d
```

---

## ❓ Dépannage rapide

### Problème : Aucun log n'arrive dans UTMStack

```bash
# 1. Vérifier les ports
netstat -uln | grep -E "7014|7005"

# 2. Vérifier les intégrations
# Aller dans UTMStack > Integrations
# Vérifier que Syslog et FortiGate sont "Enabled"

# 3. Vérifier que rsyslog tourne
systemctl status rsyslog

# 4. Redémarrer rsyslog
systemctl restart rsyslog
```

### Problème : Dashboard montre "stopped"

```bash
# Le dashboard lit le statut Docker
# Vérifier les vrais noms de conteneurs
docker ps --format "{{.Names}}"

# Redémarrer le dashboard
docker-compose restart monitoring_dashboard
```

---

## 📞 Support

- **Documentation UTMStack** : https://documentation.utmstack.com
- **Intégrations** : https://documentation.utmstack.com/integrations
- **Discord UTMStack** : https://discord.gg/ZznvZ8xcHh

---

**Version** : 2.0  
**Compatible** : UTMStack v11.2+  
**Ports** : 7005 (FortiGate), 7014 (Syslog)
